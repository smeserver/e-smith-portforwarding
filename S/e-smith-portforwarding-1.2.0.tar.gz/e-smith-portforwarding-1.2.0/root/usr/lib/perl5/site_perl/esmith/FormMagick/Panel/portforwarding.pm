#----------------------------------------------------------------------
# $Id: portforwarding.pm,v 1.38 2005/03/16 23:37:02 charlieb Exp $
# vim: ft=perl ts=4 sw=4 et:
#----------------------------------------------------------------------
# copyright (C) 2002 Mitel Networks Corporation
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
#
# Technical support for this program is available from Mitel Networks
# Please visit our web site www.e-smith.com for details.
#----------------------------------------------------------------------

package esmith::FormMagick::Panel::portforwarding;

use strict;
use esmith::ConfigDB;
use esmith::FormMagick;
use esmith::util;
use esmith::util::network qw(isValidIP);
use esmith::cgi;
use Exporter;

use constant TRUE => 1;
use constant FALSE => 0;

our @ISA = qw(esmith::FormMagick Exporter);

our @EXPORT = qw(
    show_port_forwards create_new validate_source_port
    validate_destination_port display_create_summary
    );

our $VERSION = sprintf '%d.%03d', q$Revision: 1.38 $ =~ /: (\d+).(\d+)/;
our $db = esmith::ConfigDB->open
    || die "Can't open configuration database: $!\n";

=head1 NAME

esmith::FormMagick::Panels::portforwarding - useful panel functions

=head1 SYNOPSIS

    use esmith::FormMagick::Panels::portforwarding

    my $panel = esmith::FormMagick::Panel::portforwarding->new();
    $panel->display();

=head1 DESCRIPTION

This module is the backend to the portforwarding panel, responsible for
supplying all functions used by that panel. It is a subclass of
esmith::FormMagick itself, so it inherits the functionality of a FormMagick
object.

=head2 new

This is the class constructor.

=begin testing

$ENV{ESMITH_CONFIG_DB} = "10e-smith-base/configuration.conf";

use_ok('esmith::FormMagick::Panels::portforwarding');
our $panel;
ok($panel = esmith::FormMagick::Panels::portforwarding->new(),
   "Create panel object");
isa_ok($panel, 'esmith::FormMagick::Panels::portforwarding');

=end testing

=cut

sub new {
    my $class = ref($_[0]) || $_[0];
    my $self = esmith::FormMagick->new();
    bless $self, $class;
    # Uncomment the following line for debugging.
    #$self->debug(TRUE);
    return $self;
}

=head2 show_port_forwards

This method displays the data on currently forwarded ports on
the system.

=cut

sub show_port_forwards {
    my $self = shift;
    my $q = $self->cgi;

    my $masq = $db->get('masq')
        || return $self->error('ERR_NO_MASQ_RECORD');
    my $empty = 0;
    my %tcpforwards = split /,/, $masq->prop('TCPForwards');
    my %udpforwards = split /,/, $masq->prop('UDPForwards');
    $empty = 1 if not %tcpforwards and not %udpforwards;

    my %forwards = ();
    $forwards{TCP} = \%tcpforwards;
    $forwards{UDP} = \%udpforwards;

    my $systemmode = $db->get_value('SystemMode');

    unless ($systemmode eq 'serveronly')
    {
        print $q->Tr(
            $q->td({-colspan => 2},
                '<br>' .
            $q->a({-class => "button-like",
                   -href => "portforwarding?page=0&page_stack=&Next=Create"},
               $self->localise('CREATE_RULE'))));
    }

    if ($systemmode eq 'serveronly')
    {
        $empty = 1;
    }
    unless ($empty) {
        print $q->Tr(
            $q->td({-colspan => 2}, 
                $q->p($self->localise('SHOW_FORWARDS')))),"\n";

        my $q = $self->{cgi};
        print "<tr><td colspan=\"2\">";
        print $q->start_table({-class => 'sme-border'}), "\n        ";
        print $q->Tr(
            esmith::cgi::genSmallCell(
                $q,
                $self->localise('PROTOCOL'),
                "header"
            ), "        ",
            esmith::cgi::genSmallCell(
                $q,
                $self->localise('SOURCE_PORT'),
                "header"
            ), "        ",
            esmith::cgi::genSmallCell(
                $q,
                $self->localise('DESTINATION_HOST'),
                "header"
            ), "        ",
            esmith::cgi::genSmallCell(
                $q,
                $self->localise('DESTINATION_PORT'),
                "header",
            ), "        ",
            esmith::cgi::genSmallCell(
                $q,
                $self->localise('ACTION'),
                "header",
            ), "\n        ",
        );
        foreach my $proto (sort keys %forwards) {
            if (%{ $forwards{$proto} }) {
                foreach my $sport (keys %{ $forwards{$proto} }) {
                    my ($dhost, $dport) = split /:/, 
                                          $forwards{$proto}->{$sport};
                    print $q->Tr(
                        esmith::cgi::genSmallCell($q, $proto),
                            "        ",
                        esmith::cgi::genSmallCell($q, $sport),
                            "        ",
                        esmith::cgi::genSmallCell($q, $dhost),
                            "        ",
                        esmith::cgi::genSmallCell($q, $dport || '&nbsp'),
                            "        ",
                        esmith::cgi::genSmallCell(
                            $q,
                            $q->a({href => $q->url(-absolute => 1)
                                    . "?page=3&Next=Next&protocol=$proto&"
                                    . "source_port=$sport&"
                                    . "destination_host=$dhost&"
                                    . "destination_port=$dport"},
                                $self->localise("REMOVE"))
                        ),
                            "\n        ",
                    );
                }
            }
        }
        print $q->end_table,"\n";
        print '</td></tr>';

    }
    elsif ($systemmode eq 'serveronly')
    {
        print $q->Tr(
            $q->td({-colspan => 2}, '<br>' .
                $self->localise('IN_SERVERONLY')));
    }
    else {
        print $q->Tr(
            $q->td({-colspan => 2}, '<br>' .
                $self->localise('NO_FORWARDS')));
    }
    return undef;
}

=head2 validate_source_port

This method validates the source port field in the new port forward page.

=cut

sub validate_source_port {
    my $self = shift;
    my $q = $self->{cgi};
    my $sport = $q->param('source_port');
    $sport =~ s/^\s+|\s+$//g;
    # If this is a port range, split it up and validate it individually.
    my @ports = ();
    if ($sport =~ /-/)
    {
        @ports = split /-/, $sport;
        if (@ports > 2)
        {
            $self->debug_msg("found more than 2 ports: @ports");
            return $self->localise('ERR_BADPORT');
        }
    }
    else
    {
        push @ports, $sport;
    }
    $self->debug_msg("the ports array is: @ports");
    foreach my $port (@ports)
    {
        $self->debug_msg("looping on port $port");
        if (! $self->isValidPort($port))
        {
            $self->debug_msg("returning: " . $self->localise('ERR_BADPORT'));
            return $self->localise('ERR_BADPORT');
        }
    }
    # Now, lets screen any duplicates. 
    my $protocol = $q->param('protocol');
    # Grab the existing rules for this protocol.
    my %forwards = split /,/, $db->get_prop('masq', "${protocol}Forwards");
    foreach my $psport (keys %forwards)
    {
        if ($self->detect_collision($sport, $psport))
        {
            return $self->localise('ERR_PORT_COLLISION');
        }
    }
    return 'OK';
}

=head2 detect_collision

This method looks for a collision between two ports or port ranges.

=cut

sub detect_collision
{
    my $self = shift;
    my $port_a = shift;
    my $port_b = shift;
    
    # If they're both single ports, see if they're the same.
    if (($port_a !~ /-/) && ($port_b !~ /-/))
    {
        return $port_a eq $port_b;
    }
    # If port_a is not a range but port_b is, is a in b?
    elsif ($port_a !~ /-/)
    {
        my ($b1, $b2) = split /-/, $port_b;
        return (($port_a >= $b1) && ($port_a <= $b2));
    }
    elsif ($port_b !~ /-/)
    {
        my ($a1, $a2) = split /-/, $port_a;
        return (($port_b >= $a1) && ($port_b <= $a2));
    }
    else
    {
        # They're both ranges. Do they overlap?
        my ($a1, $a2) = split /-/, $port_a;
        my ($b1, $b2) = split /-/, $port_b;
        # They can overlap in two ways. Either a1 is in b, or b1 is in a.
        if (($a1 >= $b1) && ($a1 <= $b2))
        {
            return TRUE;
        }
        elsif (($b1 >= $a1) && ($b1 <= $a2))
        {
            return TRUE;
        }
        return FALSE;
    }
}

=head2 validate_destination_port

This method validates the destination port field in the new port
forward page.

=cut

sub validate_destination_port {
    my $self = shift;
    my $dport = $self->{cgi}->param('destination_port');
    $dport =~ s/^\s+|\s+$//g;
    # If the dport is empty, that's ok. 
    return 'OK' if not $dport;

    # If this is a port range, split it up and validate it individually.
    my @ports = ();
    if ($dport =~ /-/)
    {
        @ports = split /-/, $dport;
        if (@ports > 2)
        {
            $self->debug_msg("found more than 2 ports: @ports");
            return $self->localise('ERR_BADPORT');
        }
    }
    else
    {
        push @ports, $dport;
    }
    $self->debug_msg("the ports array is: @ports");

    foreach my $port (@ports)
    {
        $self->debug_msg("looping on port $port");
        if (! $self->isValidPort($port))
        {
            $self->debug_msg("returning: " . $self->localise('ERR_BADPORT'));
            return $self->localise('ERR_BADPORT');
        }
    }
    return 'OK';
}

=head2 isValidPort

Test for a valid port.
FIXME: Remove this when 5.6 is no longer supported, and use
esmith::util::network::isValidPort instead.

=begin testing

@badports = (98765434, -183, 0, 'bad port', 'a');
@goodports = (67, 23, 1, 54736);

foreach $port (@badports) {
    $panel->{cgi}->param('destination_port' => $port);
    isnt($panel->validate_source_port(), "OK");
}
foreach $port (@goodports) {
    $panel->{cgi}->param('source_port' => $port);
    is($panel->validate_source_port(), "OK");
}

=end testing

=cut

sub isValidPort() {
    my $self = shift;
    my $port = shift;

    return FALSE unless defined $port;

    if (($port =~ /^\d+$/) &&
        ($port > 0) &&
        ($port < 65536))
    {
        return TRUE;
    }
    else {
        return FALSE;
    }
}

=head2 validate_destination_host

The purpose of this method is to validate the destination host field in the
new port forward page.

=cut

sub validate_destination_host {
    my $self = shift;
    my $dhost = $self->{cgi}->param('destination_host');
    $dhost =~ s/^\s+|\s+$//g;

    my $localip = $db->get_prop('InternalInterface', 'IPAddress');
    my $external_ip = $db->get_prop('ExternalInterface', 'IPAddress');

    if ($dhost =~ /^(localhost|127.0.0.1|$localip|$external_ip)$/i)
    {
        # localhost token gets expanded at runtime to current external IP
        $self->{cgi}->param(-name=>'destination_host', -value=>'localhost');
        return "OK";
    }

    if (isValidIP($dhost)) {
        return 'OK';
    }
    else {
        return $self->localise('ERR_BADIP');
    }
}

=head2 display_summary_create

This is a wrapper for the display_summary method, to call it in create mode. 

=cut

sub display_summary_create {
    my $self = shift;
    $self->display_summary('create');
}

=head2 display_summary_remove

This is a wrapper for the display_summary method, to call it in remove mode.

=cut

sub display_summary_remove {
    my $self = shift;
    $self->display_summary('remove');
}

=head2 display_create_summary

This method's purpose is to display a summary of the rule about to be added.

=cut

sub display_summary {
    my $self = shift;
    my $mode = shift;
    my $save = $self->localise('SAVE');
    my $cancel = $self->localise('CANCEL');
    my $output = "";
    my $q = $self->{cgi};
    $self->debug_msg("start of method");

    print "<tr><td colspan=\"2\">";

    my $description = "";
    if ($mode eq 'create') {
        $description = $self->localise('SUMMARY_ADD_DESC');
    }
    elsif ($mode eq 'remove') {
        $description = $self->localise('SUMMARY_REMOVE_DESC');
    }
    else {
        return $self->error('ERR_UNSUPPORTED_MODE');
    }

    print $q->p($description);

    my $localip = $db->get_prop('InternalInterface', 'IPAddress');
    my $external_ip = $db->get_prop('ExternalInterface', 'IPAddress');

    my $dhost = $self->get_destination_host();
    foreach my $tablearrayref (
            [$self->localise('PROTOCOL')
                => $q->param('protocol')],
            [$self->localise('SOURCE_PORT')
                => $q->param('source_port')],
            [$self->localise('DESTINATION_PORT')
                => $q->param('destination_port') || '&nbsp;'],
            [$self->localise('DESTINATION_HOST')
                => $dhost],
        )
    {
        print $q->Tr(
            $q->td({-class => 'sme-noborders-label'},
                $tablearrayref->[0],
                $q->td({-class => 'sme-noborders-content'},
                    $tablearrayref->[1]))), "\n";
    }

    if ($mode eq 'create') {
        print $q->table({-width => '100%'}, $q->Tr($q->th({-class => 'sme-layout'},
                    $q->submit(-name => 'apply',
                        -value => $self->localise("APPLY")),
                    '&nbsp;',
                    $q->submit(-name => 'cancel',
                        -value => $self->localise("CANCEL")))));
    }
    elsif ($mode eq 'remove') {
        print $q->table({-width => '100%'}, $q->Tr($q->th({-class => 'sme-layout'},
                    $q->submit( -name => 'remove',
                        -value => $self->localise("REMOVE")),
                    '&nbsp;',
                    $q->submit( -name => 'cancel',
                        -value => $self->localise("CANCEL")))));
    }
    else { 
        return $self->error('ERR_UNSUPPORTED_MODE');
    }
    $self->debug_msg("returning");

    print "</td></tr>";
    return undef;
}

=head2 remove_rule

This method is a remove wrapper for the modify method.

=cut

sub remove_rule {
    my $self = shift;
    $self->modify('remove');
}

=head2 create_new

This method is a create wrapper for the modify method.

=cut

sub create_new {
    my $self = shift;
    $self->modify('create');
}

=head2 modify

This method's purpose is to add or remove rules from the database, and then
cause the firewall rules to update.

=cut

sub modify {
    no strict 'refs';
    my $self = shift;
    my $mode = shift;
    my $q = $self->{cgi};
    $self->debug_msg("at start of modify method");

    # If the cancel button was pressed, just go back to the start page.
    if ($q->param("cancel")) {
        $self->debug_msg("the cancel button was pressed");
        $self->wherenext("Front");
    }
    else {
        # Save the changes. 
        my $proto = $q->param("protocol");
        my $sport = $q->param("source_port");
        my $dport = $q->param("destination_port");
        my $dhost = $self->get_destination_host();
        $proto =~ s/^\s+|\s+$//g;
        $sport =~ s/^\s+|\s+$//g;
        $dport =~ s/^\s+|\s+$//g;
        $dhost =~ s/^\s+|\s+$//g;

        $self->debug_msg("protocol is $proto");
        $self->debug_msg("source_port is $sport");
        $self->debug_msg("destination_port is $dport");
        $self->debug_msg("destination_host is $dhost");

        my $whichforwards = "";
        if ($proto eq 'TCP') {
            $whichforwards = 'TCPForwards';
        }
        else {
            $whichforwards = 'UDPForwards';
        }

        # Port forwarding rules are properties of the masq record under a key
        # of TCPForwards, with each one separated by commas, and the format of
        # each being, "sport,host1:dport"
        my $masq = $db->get('masq') 
            || return $self->error('ERR_NO_MASQ_RECORD');
        $self->debug_msg("fetching $whichforwards property from masq record");
        $$whichforwards = $masq->prop($whichforwards);
        $self->debug_msg("the db property is $$whichforwards");

        if ($mode eq 'create') {
            $self->debug_msg("we are in create mode");
            my $newrule = "$sport,$dhost:$dport";
            $self->debug_msg("new rule is $newrule");
            if ($$whichforwards) {
                # Look for an identical rule. 
                my $pattern; ($pattern = $newrule) =~ s/\./\\./g;
                $self->debug_msg("looking for a dup rule; pattern $pattern");
                if ($$whichforwards =~ /$pattern/) {
                    $self->debug_msg("found a duplicate rule");
                    return $self->error('ERR_DUPRULE');
                }
                $$whichforwards .= ',';
            }
            else {
                $$whichforwards = '';
            }
            $$whichforwards .= $newrule;
            $self->debug_msg("\$\$whichforwards is now $$whichforwards");
        }
        elsif ($mode eq 'remove') {
            $self->debug_msg("we are in remove mode");
            if (! $$whichforwards) {
                # The category is empty. Nothing to remove.
                return $self->error('ERR_CANNOT_REMOVE_NORULE');
            }
            my %forwards = split /,/, $$whichforwards;
            $$whichforwards = "";
            my $found = FALSE;
            foreach my $psport (keys %forwards) {
                my ($pdhost, $pdport) = split /:/, $forwards{$psport};
                $self->debug_msg("looping on $psport, $pdhost, $pdport");
                if (($sport eq $psport) &&
                    ($dport eq $pdport) &&
                    ($dhost eq $pdhost))
                {
                    $found = TRUE;
                    $self->debug_msg("found the rule to remove");
                }
                else {
                    $$whichforwards .= "$psport,$pdhost:$pdport,";
                    $self->debug_msg("\$\$whichforwards is now $$whichforwards");
                }
            }
            if (! $found) {
                return $self->error('ERR_CANNOT_REMOVE_NORULE');
            }
            $$whichforwards =~ s/,$//;
        }

        $masq->set_prop("$whichforwards", $$whichforwards);

        system("/sbin/e-smith/signal-event",
               "portforwarding-update") == 0
           || return $self->error('ERR_NONZERO_RETURN_EVENT');

        return $self->success();
    }
}

=head2 get_destination_host

Get the 'destination_host' parameter, and fold it to 'localhost' if it
matches any local interface IP address.

=cut

sub get_destination_host
{
    my $self = shift;
    my $q = $self->{cgi};
    my $dhost = $q->param("destination_host");
    my $localip = $db->get_prop('InternalInterface', 'IPAddress');
    my $external_ip = $db->get_prop('ExternalInterface', 'IPAddress');

    if ($dhost =~ /^(127.0.0.1|$localip|$external_ip)$/i)
    {
        # localhost token gets expanded at runtime to current external IP
        $dhost = 'localhost';
    }
    return $dhost;
}

1;
